"""NablaMath mathematical domain module."""
